package Task7;

public interface Printable {
    public void print();
}
