package Task7;

public class Main {
    public static void main(String[] args) {
        Store store = new Store();
        store.fillingTheStoreWithGoods();
        store.doInspection();
    }
}
